﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;

namespace HousingProject.Model
{
    public class HousingContext : DbContext
    {

       public  DbSet<Apartment> Apartments { get; set; }
       public  DbSet<Applicant> Applicants { get; set; }
       public DbSet<ApplicantApartment> ApplicantApartments { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(@"Server=localhost;Database=HousingDB");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //Here PK is added to ApplicantApartment
            modelBuilder.Entity<ApplicantApartment>().HasKey(k => new { k.ApplicantId, k.ApartmentId });

            //Add relation to Applicant from ApplicantApartment
            modelBuilder.Entity<ApplicantApartment>()
                .HasOne(b => b.Applicant)
                .WithMany(bc => bc.ApplicantApartments)
                .HasForeignKey(k => k.ApplicantId);

            //Add relation to Apartment from ApplicantApartment
            modelBuilder.Entity<ApplicantApartment>()
                .HasOne(b => b.Apartment)
                .WithMany(bc => bc.ApplicantApartments)
                .HasForeignKey(k => k.ApartmentId);

        }
    }
}
