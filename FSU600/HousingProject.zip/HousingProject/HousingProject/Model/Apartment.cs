﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HousingProject.Model
{
    public class Apartment
    {
        
        [Key,StringLength(8)]
        public string Id { get; set; }

        [Required]
        public int AreaInSqm { get; set; }

        [Required]
        public int DoorNumber { get; set; }

        [Required]
        public string Location { get; set; }

        public string City { get; set; }

        [MinLength(5), MaxLength(5)]
        public int Pincode { get; set; }
        //commenting this as many-to-many table is referred below.
        //public int AppliedBy { get; set; }
        //public Applicant Applicant { get; set; }

        public List<ApplicantApartment> ApplicantApartments { get; set; }
    }
}
