﻿using System;
namespace HousingProject.Model
{
    public class ApplicantApartment
    {

        public string ApplicantId { get; set; }

        public string ApartmentId { get; set; }

        public Applicant Applicant { get; set; }

        public Apartment Apartment { get; set; }
    }
}
