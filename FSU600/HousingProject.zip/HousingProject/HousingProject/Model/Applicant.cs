﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HousingProject.Model
{
    public class Applicant
    {
      
        [Key,StringLength(12)]
        public string SSN { get; set; }
        [Required,StringLength(30)]
        public string Name { get; set; }
        [Required]
        public string emailid { get; set; }

        [MinLength(10),MaxLength(10)]
        public int PhoneNum { get; set; }

        public List<ApplicantApartment> ApplicantApartments { get; set; }
    }
}
