﻿using System;
using System.Collections.Generic;
using System.Linq;
using HousingProject.Model;
using Microsoft.EntityFrameworkCore;

namespace HousingProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello User, Welcome to the Housing portal\n");
            Console.WriteLine("Please enter one option from the following menu\n\n" +
                "1.View all the available apartments\n\n" +
                "2.View all the applicant details\n\n" +
                "3.Place your interest for an apartment\n\n" +
                "4.Update an apartment listing\n\n" +
                "5.Remove an apartment listing\n\n" +
                "----------------------------------------------------");
            int userOption = int.Parse(Console.ReadLine());

            if (userOption < 1 || userOption > 5)
            {
                Console.WriteLine("Invalid option entered !");
                return;
            }

            switch (userOption)
            {

                case 1:
                    Console.WriteLine("**** Here are the available apartments ****");
                    ListApartments();
                    break;

                case 2:
                    Console.WriteLine("**** Here are the applicant details ****");
                    ListApplicants();
                    break;

                case 3:
                    Console.WriteLine("Enter your SSN in YYYYMMDDXXXX Format :");
                    string UserSSN = Console.ReadLine();
                    CreateRequest(UserSSN);
                    break;

                case 4:
                    Console.WriteLine("Enter the Apartment ID to be updated: ");
                    
                    string AptId = Console.ReadLine();
         
                    //Console.WriteLine("Enter the area");
                   // int Aptarea = int.Parse(Console.ReadLine());
                    UpdateApartment(AptId);
                    break;

                case 5:
                    Console.WriteLine("Enter the Apartment ID to be removed from the listing : ");
                    string ApmtId = Console.ReadLine();
                    RemoveApartment(ApmtId);
                    break;

                default:
                    return;
            }

        }

        #region Read
        //Read property - Apartments and Applicants
        //List of apartments with applied applicants SSN
        static private void ListApartments()
        {
            using (HousingContext db = new HousingContext())
            {
                List<Apartment> apartmentList = db.Apartments.Include(AppliedBy=> AppliedBy.ApplicantApartments)
                    .ThenInclude(Apts => Apts.Applicant)
                    .ToList();
                Console.WriteLine("----------------------------------------------------------------");
               
                foreach(var apt in apartmentList)
                {
                    string AppliedSSN = "";
                    foreach (var Applied in apt.ApplicantApartments)
                        AppliedSSN += Applied.Applicant.SSN + " ";

                        Console.WriteLine(apt.Id + " | " + apt.AreaInSqm + " | " + apt.Location + " | " + apt.City + "|" + AppliedSSN );
                }
            }
        }
        //List of applicants with applied apartments Id.
        static private void ListApplicants()
        {
            using (HousingContext db = new HousingContext())
            {
                List<Applicant> applicantList = db.Applicants.Include(AppliedFor => AppliedFor.ApplicantApartments)
                    .ThenInclude(Appls => Appls.Apartment)
                    .ToList();

                Console.WriteLine("-----------------------------------------------------------------------");
                foreach (var appl in applicantList)
                {
                    string AppliedAptId = "";
                    foreach (var Applied in appl.ApplicantApartments)
                        AppliedAptId += Applied.Apartment.Id + " ";
                    Console.WriteLine(appl.SSN + " | " + appl.Name + " | " + appl.emailid + " | " + AppliedAptId);
                }

            }

        }
        #endregion

        #region Create
        //Create property -this will create a request for the user with specified Apartment ID
        static private void CreateRequest(string UserSSN)
        {
            using (HousingContext db = new HousingContext())
            {
                //check if the user SSN already exists in the database
                Applicant applicant = db.Applicants.Where(ApplSSN => ApplSSN.SSN == UserSSN).FirstOrDefault();
                {
                    if (applicant != null)
                    {
                        Console.WriteLine("Enter the Apartment ID to place your request: ");
                        string AptId = Console.ReadLine();
                        //check if the apartment id exists in the database
                        Apartment apartment = db.Apartments.Where(AprtId => AprtId.Id == AptId).FirstOrDefault();
                        
                            if (apartment != null)
                            {
                                ApplicantApartment applicantApartment = new ApplicantApartment();
                                applicantApartment.ApplicantId = applicant.SSN;
                                applicantApartment.ApartmentId = apartment.Id;
                                db.ApplicantApartments.Add(applicantApartment);
                                db.SaveChanges();
                            Console.WriteLine("\nRecord added\n");
                            ListApplicants();
                            }
                            else
                            {
                                Console.WriteLine("There's no apartment with the given id!");
                            }
                    }
                    else
                    {
                        Console.WriteLine("Sorry, you don't have an account !");
                    }
                }   
            }
        }
        #endregion
        
        #region Update
        static private void UpdateApartment(string aprtId)
        {
          
            using (HousingContext db = new HousingContext())
            {
                var apartment = db.Apartments.Where(AprtId => AprtId.Id == aprtId).FirstOrDefault();
                if(apartment != null)
                {
                    Console.WriteLine("What do you want to update?\n\n1.Area\n\n2.Location");
                    int UserUpdateoption = int.Parse(Console.ReadLine());
                    if (UserUpdateoption < 1 || UserUpdateoption > 2)
                    {
                        Console.WriteLine("Invalid option entered");
                        return;
                    }
                    if (UserUpdateoption == 1)
                    //for the record with entered Apartment ID,updating the record in database
                    {
                        Console.WriteLine("Enter the area");
                        int Aprtarea = int.Parse(Console.ReadLine());
                        apartment.AreaInSqm = Aprtarea;
                    }
                    if (UserUpdateoption == 2)
                    {
                        Console.WriteLine("Enter the Location");
                        string AprtLocation = Console.ReadLine();
                        apartment.Location = AprtLocation;
                    }

                    db.SaveChanges();
                    Console.WriteLine("\nUpdate done !\n");
                    ListApartments();
                }
                else
                {
                    Console.WriteLine("\nThere's no apartment with the given id!");
                }
                
                }
        }
        #endregion

        #region Delete
        static private void RemoveApartment(string apmtId)
        {
            using (HousingContext db = new HousingContext())
            {
                var apartment = db.Apartments.Where(ApmntId => ApmntId.Id == apmtId).FirstOrDefault();
                if (apartment != null)
                {
                    //for the record with entered Apartment ID,removing the record from database
                    db.Apartments.Remove(apartment);
                    db.SaveChanges();
                    Console.WriteLine("\nRecord successfully removed\n");
                    ListApartments();
                }
                else
                {
                    Console.WriteLine("\nThere's no apartment with the given id!");
                }

            }

        }
        #endregion

    }
}
