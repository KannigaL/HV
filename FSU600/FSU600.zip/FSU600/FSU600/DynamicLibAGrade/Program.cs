﻿using System;
using System.Linq;
using System.Collections.Generic;
using static System.Linq.Enumerable;
using System.Linq.Expressions;


namespace DynamicLibAGrade
{
    class Program
    {
        static void Main(string[] args)
        {
     
            // STEP 1: Read each line of the file into a string array. Each element
            // of the array is one line of the file.

            string[] employees = System.IO.File.ReadAllLines(@"/Users/kanniga/Desktop/FSU600/FSU600/DynamicLibAGrade/Employees.txt");           //point this to respective directory when running from other system

            //Display the file contents in console
            System.Console.WriteLine("List of Employee names with \"an\" in Employee.txt:\n ");

            //create a list of string type.
            List<String> employeeList = new List<string>();

            // Display the file contents by using a foreach loop.
            foreach (string line in employees)
            { 
                //Add employee details in employeeList
                employeeList.Add(line);
            }

            //all the fields are read as string and separated by "|"
            //index [0] - employee name
            //index[1]  - dept
            //index[2]  - work experience

            //Q1 - Filter employee name which contains "an"
            List<String> filteredList = employeeList.Select(x => x.Split("|")[0]).Where(x => x.Contains("an")).ToList();

            foreach (String s in filteredList)
            {
                Console.WriteLine("\t" + s);
            }

            //Q2 - Map function - to mainpulate the employee list and return only the employee names
            List<String> filteredName = employeeList.Select(x => x.Split("|")[0]).ToList();
            System.Console.WriteLine("\nName of All employees:\n ");
            foreach (String s in filteredName)
            {
                Console.WriteLine("\t" + s);
            }

            //Q3 - Reduce function - to return the sum of experience of the employess
            List<String> filteredExp = employeeList.Select(x => x.Split("|")[2]).ToList();

            //Converting experience from string to Int and sum.
            IEnumerable<int> convertToInt = filteredExp.Select(s => int.Parse(s));
            int sumOfExp = convertToInt.Aggregate((x, y) => x + y);
            Console.WriteLine("\nSum : \t" + sumOfExp);
            
            Console.WriteLine("\nPress any key to exit.");
            System.Console.ReadKey();
        }
    }
}
