﻿using System;
using System.Collections.Generic;

namespace DynamicLibBGrade
{
    public class DLibBGrade
    {
        public static string Welcome()
        {
            return "Hello User\n";
        }

        public static List<int> RandomizeList(List<int> myList, int fromRange, int toRange)
        {
            Random rnd = new Random();

            for (int i = 0; i < toRange; i++)
            {
                myList.Add(rnd.Next(fromRange, toRange));
            }

            //uncomment this to display the list in console.commented to reduce the time while modifying list.
            /*foreach (var randomint in myList)
            {
                Console.WriteLine(randomint);
            }*/
            return myList;
  
        }

        public static void RandomizeStack(Stack<int> myStack, int fromRange, int toRange)
        {
            Random rnd = new Random();

            for (int i = 0; i < toRange; i++)
            {
                myStack.Push(rnd.Next(fromRange, toRange));
                //uncomment this to display the Stack in console.commented to reduce the time while modifying Stack.
                //Console.WriteLine("Stack:" +rnd.Next(fromRange, toRange));
            }

        }

        public static void RandomizeQueue(Queue<int> myQueue, int fromRange, int toRange)
        {
            Random rnd = new Random();

            for (int i = 0; i < toRange; i++)
            {
                myQueue.Enqueue(rnd.Next(fromRange, toRange));
                //uncomment this to display the queue in console.commented to reduce the time while modifying queue.
                // Console.WriteLine("Queue:" + rnd.Next(fromRange, toRange));
            }
        }

        public static void createDictionary(Dictionary<int,int> myDict,int fromRange, int toRange)
        {
            Random rnd = new Random();
            for (int i = 0; i < toRange; i++)
            {
                myDict.Add(i, rnd.Next(fromRange, toRange));
            }
            //uncomment this to display the Dictionary in console.commented to reduce the time while modifying Dictionary.
            /*foreach (var newDict in myDict)
                Console.WriteLine("Key: {0}, Value: {1}", newDict.Key, newDict.Value);*/
        }

        public static void createSortedDict(SortedDictionary<int,int> mySortedDict, int fromRange,int toRange)
        {
            int key = toRange;
            Random rnd = new Random();
            for (int i = 0; i < toRange; i++)
            {
                mySortedDict.Add(key--, rnd.Next(fromRange, toRange));
            }
            //uncomment this to display the SortedDictionary in console.commented to reduce the time while modifying SortedDictionary.
            /*foreach (var newSortedDict in mySortedDict)
                Console.WriteLine("Key: {0}, Value: {1}", newSortedDict.Key, newSortedDict.Value);*/
        }

        public static void GenerateHashSet(HashSet<int> myHashSet, int fromRange, int toRange)
        {

            Random rnd = new Random();
            for (int i = 0; i < toRange ; i++)
            {
                myHashSet.Add(rnd.Next(fromRange, toRange));
                //uncomment this to display the HashSet in console.commented to reduce the time while modifying HashSet.
                //Console.WriteLine("HashSet:" +rnd.Next(fromRange, toRange));
            }


        }
        
    }
}
