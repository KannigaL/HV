﻿using System;
using System.Linq;

namespace Algorithms
{

    public class Sorting
    {


        //Swapping the elements if one is greater than the other.
        public static void Swap(int[] myArray, int m , int n)
        { 
            int temp;
            temp = myArray[m];
            myArray[m] = myArray[n];
            myArray[n] = temp;
        }

        //Generating Random elements in an array with min and max range
        public static int[] Randomize(int[] myArray, int fromRange, int toRange)
        {
            Random rnd = new Random();
            //Console.Write(" Unsorted array: ");
            //Console.Write("[ ");
            for (int i = 0; i < myArray.Length; i++)
            {
                myArray[i] = rnd.Next(fromRange,toRange);
                //Console.Write(+myArray[i] + " ");
            }
            //Console.Write("]\n");
            //Console.WriteLine();
            return myArray;

        }

        //Generating Random elements in an array without duplicates, (to check search algortihm efficiency without duplicates )
        //source : https://stackoverflow.com/questions/45905524/c-sharp-random-number-generator-in-an-array-with-no-duplicates

        public static int[] ArrayWithoutDuplicates(int size)
        {
            Random rand = new Random();
            return Enumerable.Repeat<int>(0, size)
                .Select((x, i) => new { i = i, rand = rand.Next() })
                .OrderBy(x => x.rand)
                .Select(x => x.i).ToArray();
        }

        public static void Prepare(int arraySize)
        {
            int[] myArray = new int[arraySize];
            int maxRange = 10 * arraySize;
    
        }

        //Bubble sort 
        public static void BubbleSort(int[] myArray)
        {
            for (int i = 0; i < myArray.Length; i++)
            {
               
                for (int j = 0; j < myArray.Length - 1; j++)
                {
                    
                    if (myArray[j] > myArray[j + 1])
                    {
                        
                        Swap(myArray, j + 1, j);
                    }
                }
               
            }
            Console.Write(" Sorted array: ");
            Console.Write("[ ");
            foreach (int sortedArray in myArray)
                Console.Write(sortedArray + " ");
            Console.Write("]\n"); 
        }

        //Selection sort
        public static void SelectionSort(int[] myArray)
        {
                                                               
            for (int i = 0; i < myArray.Length - 1; i++)
            {
                int Min = i;
                for (int j = i + 1; j < myArray.Length; j++)
                {
                    if (myArray[Min] > myArray[j])
                    {
                        Min = j;                                               
                    }
                }
                Swap(myArray,i, Min);
            }
            //Console.Write(" Sorted array: ");
            //Console.Write("[ ");
            //    foreach (int sortedArray in myArray)
            //    Console.Write(sortedArray + " ");
            //Console.Write("]\n");
            //Console.Read();
        }
       
        //Insertion sort
        public static void InsertionSort(int[] myArray)
        {
            int temp, flag;
            for(int i =1; i< myArray.Length;i++)
            {
                temp = myArray[i];
                flag = 0;
                for(int j = i-1;j>=0 && flag !=1;)
                {
                    if (temp < myArray[j])
                    {
                        myArray[j + 1] = myArray[j];
                        j--;
                        myArray[j + 1] = temp;
                    }
                    else flag = 1;
                }
            }
            Console.Write("Sorted array:");
            Console.Write("[ ");
            for (int i=0;i < myArray.Length; i++)
            {
                Console.Write(myArray[i] + " ");
            }
            Console.Write("]");
        }

        //Merge sort
        
        public static void MergeSort(int[] myArray)
        {
            //int[] myArray = new int[arraySize];
            SortMerge(myArray, 0, myArray.Length - 1);
            //Console.WriteLine("Sorted Array:");
            //for (int i = 0; i < myArray.Length; i++)
            //Console.WriteLine(myArray[i] + " ");
            
           
            //Console.ReadLine();

        }
 
        static public void Merge(int[] myArray, int left, int mid, int right)
        {
            int[] leftArray = new int[mid - left + 1];
            int[] rightArray = new int[right - mid];

            Array.Copy(myArray, left, leftArray, 0, mid - left + 1);
            Array.Copy(myArray, mid + 1, rightArray, 0, right - mid);

            int i = 0;
            int j = 0;
            for (int k = left; k < right + 1; k++)
            {
                if (i == leftArray.Length)
                {
                    myArray[k] = rightArray[j];
                    j++;
                }
                else if (j == rightArray.Length)
                {
                    myArray[k] = leftArray[i];
                    i++;
                }
                else if (leftArray[i] <= rightArray[j])
                {
                    myArray[k] = leftArray[i];
                    i++;
                }
                else
                {
                    myArray[k] = rightArray[j];
                    j++;
                }
            }
        }

        static public void SortMerge(int[] myArray, int left, int right)
        {
            if (right > left)
            {
                int mid= (left + right) / 2;

                SortMerge(myArray, left, mid);              //divide array into two halves and sort recursively
                SortMerge(myArray, mid + 1, right);
                Merge(myArray, left, mid, right);
            }
        }

        //Quick sort
        public static void QuickSort(int[] myArray)
        {

            int left = 0;
            int right = myArray.Length - 1;
            QuickSortMain(myArray, left, right);
            Console.Write("Sorted array:");
            Console.Write("[ ");
            for (int i = 0; i < myArray.Length; i++)
            {
                Console.Write(myArray[i] + " ");
            }
            Console.Write("]");

        }

        public static void QuickSortMain(int[] myArray,int left,int right)
        {
            int pivot = myArray[(left + right) / 2];
            int leftHold = left;
            int rightHold = right;

            while (leftHold < rightHold)
            {
                while ((myArray[leftHold] < pivot) && (leftHold <= rightHold)) leftHold++;
                while ((myArray[rightHold] > pivot) && (rightHold >= leftHold)) rightHold--;

                if (leftHold < rightHold)
                {
                    //call swap method here
                    //Swap(myArray,leftHold,rightHold);
                    int tmp = myArray[leftHold];
                    myArray[leftHold] = myArray[rightHold];
                    myArray[rightHold] = tmp;
                   
                    if (myArray[leftHold] == pivot && myArray[rightHold] == pivot)
                        leftHold++;  
                }
               
            }
           if (left < leftHold - 1) QuickSortMain(myArray, left, leftHold - 1);
           if (right > rightHold + 1) QuickSortMain(myArray, rightHold + 1, right);  
        }

        //Linear Search
        public static int search(int[] array, int x)
        {
            //Console.WriteLine("unsorted Array linear search: ");
            //foreach (int s in array) Console.Write(s + " ");
           // Console.WriteLine();
            Console.WriteLine("search element" + x);
            int arraySize = array.Length;
            for (int i = 0; i < arraySize; i++)
            {
                if (array[i] == x)
                    return i;
            }
            return -1;
        }
       
        public static void LinearSearch(int[] array, int x)
        {
          int result = search(array, x);
            if (result == -1)
                Console.WriteLine("OOPS ! Element is not present in the given array");
            else
                Console.WriteLine("Element is at index " + result);
        }

        //Binary search
        
        public static void BinarySearch(int[] array, int x)
        {
            //Console.WriteLine("Sorted Array: ");
            //foreach (int s in array) Console.Write(s + " ");
           // Console.WriteLine();

            int min = 0;
            int max = array.Length - 1;
            while (min <= max)
            {
                int mid = (min + max) / 2;
                if (x < array[mid])
                {
                    max = mid -  1;
                }
                else if (x > array[mid])
                {
                    min = mid + 1;
                }
                else if (x == array[mid])
                {
                    Console.WriteLine("Element {0} is at index {1}", x, mid);                           //mid gives the  element index
                    //Console.WriteLine("Element {0} is at {1} location ", x, mid + 1);                 //mid + 1 gives the element location.
                    return;
                }
            }
            Console.WriteLine("OOPS ! Element is not present in the given array");   
        }

        public static void LambdaSort(int[] myArray)
        {
            Array.Sort(myArray, (x, y) => x.CompareTo(y));

        }

        public static int LambdaSearch(int[] myArray, int searchElement)
        {
             return Array.IndexOf(myArray, searchElement);
           
        }

    }
}


       

   




