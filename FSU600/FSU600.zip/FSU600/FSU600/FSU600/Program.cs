﻿using System;

using Algorithms;

namespace FSU600
{
    class Program
    {
        //define delegate
        public delegate string HelloDelegate(string name);
        public delegate void SortDelegate(int[] myArray);
        public delegate void SearchMultipleDelegate(int[] myArray);
        public delegate void SearchDelegate(int[] array, int x);
        

        static void Main(string[] args)
        {
            HelloDelegate obj = new HelloDelegate(Welcome);
            Console.WriteLine("Please Enter your name:\n");
            string msg = obj (Console.ReadLine());
            Console.WriteLine(msg);

            //Get the user input for array size
            Console.WriteLine("Enter the size of array:\n");
            int arraySize = int.Parse(Console.ReadLine());

            Sorting sorting = new Sorting();

            //Preparing the size of array with user input
            int[] myArray = new int[arraySize];
            
            //int maxRange = 10 * arraySize;                                      //comment this to run sort for larger array size
            int maxRange = 1 * arraySize;                                         //use this when using for larger array size

            //call to generate random elements of array
            int[] array = Sorting.Randomize(myArray, 0, arraySize);

            Console.WriteLine("Do you want to search or sort?\n");
            Console.WriteLine("Press 1 for Search\n\nPress 2 to Sort");

            //Search lambda function
           // Func<int[], int, int> searchElement = (myName, search) => Array.IndexOf(myName, search);
            //Calling Search lambda function
            //Console.WriteLine("search Index : "+searchElement(array, array[0]));

             

            int SearchOrSort = int.Parse(Console.ReadLine());

            if (SearchOrSort < 1 || SearchOrSort > 2)
            {
                Console.WriteLine("Invalid Option !");
                return;
            }
            if (SearchOrSort == 1)
            {
                Console.WriteLine("Press 1 for Linear Search\n");
                Console.WriteLine("Press 2 for Binary search\n");
                Console.WriteLine("Press 3 for Lambda search\n");
                int searchOption = int.Parse(Console.ReadLine());

                    //Console.WriteLine("Please enter the search element:\n");
                    //int searchElement = int.Parse(Console.ReadLine());

                SearchDelegate searchDelegate;

                switch (searchOption)
                    {

                        case 1:
                            
                            int[] searchArray = Sorting.ArrayWithoutDuplicates(arraySize);

                            //invoke delegate
                            searchDelegate = new SearchDelegate(Sorting.LinearSearch);
                            //DisplayRunningTimeSearch(searchDelegate, searchArray, searchArray[0]);
                            //DisplayRunningTimeSearch(searchDelegate, searchArray, searchArray[searchArray.Length / 2]);
                            DisplayRunningTimeSearch(searchDelegate, searchArray, searchArray[searchArray.Length-1]);
                            break;

                        case 2:
                            int[] binarySearchArray = Sorting.ArrayWithoutDuplicates(arraySize);

                            searchDelegate = new SearchDelegate(Sorting.BinarySearch);
                            Array.Sort(binarySearchArray);

                            //DisplayRunningTimeSearch(searchDelegate, binarySearchArray, binarySearchArray[0]);
                            //DisplayRunningTimeSearch(searchDelegate, binarySearchArray, binarySearchArray[binarySearchArray.Length / 2]);
                            DisplayRunningTimeSearch(searchDelegate, binarySearchArray, binarySearchArray[binarySearchArray.Length - 1]);

                            break;

                        case 3:
                            int[] lambdaSearchArray = Sorting.ArrayWithoutDuplicates(arraySize);

                            Func<int[], int, int> lambdaSearch = (myName, search) => Sorting.LambdaSearch(myName, search);

                            DateTime startTime = DateTime.Now;
                            //lambdaSearch(lambdaSearchArray, lambdaSearchArray[0]);
                            //lambdaSearch(lambdaSearchArray, lambdaSearchArray[lambdaSearchArray.Length/2]);
                            lambdaSearch(lambdaSearchArray, lambdaSearchArray[lambdaSearchArray.Length - 1]);

                            TimeSpan endTime = DateTime.Now - startTime;
                            Console.WriteLine("It took {0:0.00} ms to search.\n", endTime.TotalMilliseconds);

                            break;
                    default:
                            Console.WriteLine("Invalid option\n");
                            break;

                    }
                }
            
            if (SearchOrSort == 2)
            {
                Console.WriteLine(" Select one sorting option\n");
                Console.WriteLine("1.Bubble sort");
                Console.WriteLine("2.Selection sort");
                Console.WriteLine("3.Insertion sort");
                Console.WriteLine("4.Merge sort");
                Console.WriteLine("5.Quick sort");
                Console.WriteLine("6.Lambda Sort");

                int sortOption = int.Parse(Console.ReadLine());
                if (sortOption > 6 || sortOption < 1)
                {
                    Console.WriteLine("Invalid option");
                    return;
                }

                Console.WriteLine("You have selected: " + sortOption);

                //instantiating delegate
                SortDelegate sortDelegate;
              


                switch (sortOption)
                {
                    case 1:
                        sortDelegate = new SortDelegate(Sorting.BubbleSort);
                        DisplayRunningTime(sortDelegate, array);
                        break;

                    case 2:
                        sortDelegate = new SortDelegate(Sorting.InsertionSort);
                        DisplayRunningTime(sortDelegate, array);
                        break;

                    case 3:
                        sortDelegate = new SortDelegate(Sorting.SelectionSort);
                        DisplayRunningTime(sortDelegate, array);
                        break;

                    case 4:
                        sortDelegate = new SortDelegate(Sorting.MergeSort);
                        DisplayRunningTime(sortDelegate, array);
                        break;

                    case 5:
                        sortDelegate = new SortDelegate(Sorting.QuickSort);
                        DisplayRunningTime(sortDelegate, array);
                        break;

                    case 6:
                        sortDelegate = new SortDelegate(Sorting.LambdaSort);
                        DisplayRunningTime(sortDelegate, array);
                        break;

                    default:
                        Console.WriteLine("Invalid option\n");
                        break;

                }
            } 
        }

        public static string Welcome(string name)
        {
            return ("Hello " + name +  " Welcome!\n");
        }

        public static void DisplayRunningTime(SortDelegate sortDelegate,int[] myArray)
        {
            DateTime startTime = DateTime.Now;
            sortDelegate(myArray);
            TimeSpan endTime = DateTime.Now - startTime;
            Console.WriteLine("It took {0:0.00} ms to sort.\n", endTime.TotalMilliseconds);
        }

        public static void DisplayRunningTimeSearch(SearchDelegate searchDelegate, int[] myArray,int x)
        {
            DateTime startTime = DateTime.Now;
            searchDelegate(myArray, x);
            TimeSpan endTime = DateTime.Now - startTime;
            Console.WriteLine("It took {0:0.00} ms to search.\n", endTime.TotalMilliseconds);
        }
    }
      
}


  

    
