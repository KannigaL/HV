﻿using System;
namespace FSU600
{
    public class DynamicLib
    {
        public DynamicLib()
        {
        }
    }
}
