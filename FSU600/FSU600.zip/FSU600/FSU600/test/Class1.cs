﻿using System;

namespace test
{
    public class Class1
    {
    }
}
