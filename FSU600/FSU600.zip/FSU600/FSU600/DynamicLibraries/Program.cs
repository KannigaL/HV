﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using DynamicLibBGrade;


namespace DynamicLibraries
{
    class Program
    {
        static void Main(string[] args)
        {
            DLibBGrade.Welcome();
            Console.WriteLine(DLibBGrade.Welcome());

            List<int> myList = new List<int>();
            Stack<int> myStack = new Stack<int>();
            Queue<int> myQueue = new Queue<int>();
            Dictionary<int, int> myDict = new Dictionary<int, int>();
            SortedDictionary<int, int> mySortedDict = new SortedDictionary<int, int>();
            HashSet<int> myHashSet = new HashSet<int>();

            //calling dll
            DLibBGrade dLibBGrade = new DLibBGrade();

            //Get user input to create data structure as required

            Console.WriteLine("Please enter an option to create\n");
            Console.WriteLine("1.List\n\n2.Stack\n\n3.Queue\n\n4.Dictionary\n\n5.Sorted Dictionary\n\n6.HashSet\n");
            int Options = int.Parse(Console.ReadLine());

            if (Options >= 1 && Options <= 6)
            {
                //get the size of input
                
                Console.WriteLine("Enter the size:\n");
                int CollectionSize = int.Parse(Console.ReadLine());
                switch (Options)
                {
                    case 1:
                       
                        DLibBGrade.RandomizeList(myList, 0, CollectionSize);
                        break;

                    case 2:
                        
                        DLibBGrade.RandomizeStack(myStack, 0, CollectionSize);
                        break;

                    case 3:
                        
                        DLibBGrade.RandomizeQueue(myQueue, 0, CollectionSize);
                        break;

                    case 4:
                        
                        DLibBGrade.createDictionary(myDict, 0, CollectionSize);
                        break;

                    case 5:
                       
                        DLibBGrade.createSortedDict(mySortedDict, 0, CollectionSize );
                        break;

                    case 6:
                        DLibBGrade.GenerateHashSet(myHashSet, 0, CollectionSize);
                        break;

                    default:
                        Console.WriteLine("Invalid option!\n");
                        break;

                }
            }
            else
            {
                Console.WriteLine("Invalid Option!\n");
                return;
            }

            Console.WriteLine("Do you want to modify? Y/N\n");
            string modify = Console.ReadLine();
            
            if (modify == "Y")
                {
                Console.WriteLine("Please enter one option\n");
                }
            else
                {
                Console.WriteLine("Exiting...!\n");
                return;
                }
            
            //Post collections creation, get user input to add / remove / search /access by index
            
            Console.WriteLine("1.Addition of an element\n\n2.Search an element\n\n3.Deletion of an element\n\n4.Access an element by index\n");
            int ModifyOptions = int.Parse(Console.ReadLine());

            if (ModifyOptions >= 1 && ModifyOptions <= 4)
            {
                switch(ModifyOptions)
                {

                    case 1:
                        Console.WriteLine("Enter an element to add:\n");
                        int addElement = int.Parse(Console.ReadLine());

                        DateTime addStartTime = DateTime.Now;
                        if (Options == 1)
                            {
                                myList.Add(addElement);
                            }
                            else if (Options == 2)
                            {
                                myStack.Push(addElement);
                            }
                                
                            else if (Options == 3)
                            {
                                myQueue.Enqueue(addElement);
                            }
                            else if (Options == 4)
                            {
                                myDict.Add(addElement, addElement);
                                
                            }
                            else if (Options == 5)
                            {
                                mySortedDict.Add(addElement,addElement);
                            }
                            else if (Options == 6)
                            {
                                myHashSet.Add(addElement);
                            }
                        TimeSpan AddendTime = DateTime.Now - addStartTime;
                        Console.WriteLine("It took {0:0.00} ms to add.\n", AddendTime.TotalMilliseconds);

                        break;

                    case 2:
                            Console.WriteLine("Enter an element to be searched:\n");
                            int searchElement = int.Parse(Console.ReadLine());

                            DateTime searchStartTime = DateTime.Now;

                        if (Options == 1)
                            {
                                myList.Contains(searchElement);
                            }
                            else if (Options == 2)
                            {
                                myStack.Contains(searchElement);
                            }

                            else if (Options == 3)
                            {
                                myQueue.Contains(searchElement);
                            }
                            else if (Options == 4)
                            {
                                myDict.ContainsKey(searchElement);
                            }
                            else if (Options == 5)
                            {
                                mySortedDict.ContainsKey(searchElement);

                            }
                            else if (Options == 6)
                            {
                                myHashSet.Contains(searchElement);
                            }

                        TimeSpan searchendTime = DateTime.Now - searchStartTime;
                        Console.WriteLine("It took {0:0.00} ms to search.\n", searchendTime.TotalMilliseconds);

                        break;

                    case 3:
                        Console.WriteLine("Enter an element to be removed:\n");
                        int delElement = int.Parse(Console.ReadLine());

                        DateTime removeStartTime = DateTime.Now;
                        if (Options == 1)
                            {
                                myList.Remove(delElement);
                            }
                            else if (Options == 2)
                            {
                                myStack.Pop();
                            }

                            else if (Options == 3)
                            {
                                myQueue.Dequeue();
                            }
                            else if (Options == 4)
                            {
                                myDict.Remove(delElement);
                            }
                            else if (Options == 5)
                            {
                                mySortedDict.Remove(delElement);

                            }
                            else if (Options == 6)
                            {
                                myHashSet.Remove(delElement);
                            }

                        TimeSpan removeendTime = DateTime.Now - removeStartTime;
                        Console.WriteLine("It took {0:0.00} ms to remove.\n", removeendTime.TotalMilliseconds);

                        break;

                    case 4:
                        Console.WriteLine("Enter the element index:\n");
                        int accessElement = int.Parse(Console.ReadLine());

                        DateTime accessStartTime = DateTime.Now;
                        if (Options == 1)
                        {
                            myList.IndexOf(accessElement);
                        }
                        else if (Options == 2)
                        {
                            myStack.ElementAt(accessElement);
                        }

                        else if (Options == 3)
                        {
                            myQueue.ElementAt(accessElement);

                        }
                        else if (Options == 4)
                        {
                           myDict.Keys.ElementAt(accessElement);
                        }

                        else if (Options == 5)
                        {
                            mySortedDict.Keys.ElementAt(accessElement);

                        }
                        else if (Options == 6)
                        {
                            myHashSet.ElementAt(accessElement);
                        }

                        TimeSpan accessendTime = DateTime.Now - accessStartTime;
                        Console.WriteLine("It took {0:0.00} ms to access.\n", accessendTime.TotalMilliseconds);

                        break;
                }
            }
            else
            {
                Console.WriteLine("Invalid Option entered!");
            }
        }

    }
}
